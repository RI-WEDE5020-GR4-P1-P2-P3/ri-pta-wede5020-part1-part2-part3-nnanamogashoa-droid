// This script runs when the page finishes loading
document.addEventListener("DOMContentLoaded", function() {

  // Get the name of the current page (for example: "index.html" or "product.html")
  var currentPage = window.location.pathname.split("/").pop();
  
  // If the page name is empty (sometimes happens), set it to index.html
  if (currentPage === "" || currentPage === undefined) {
    currentPage = "index.html";
  }

  // Get all the links in the navigation
  var navLinks = document.querySelectorAll("nav a");

  for (var i = 0; i < navLinks.length; i++) {
    var link = navLinks[i];
    var linkPage = link.getAttribute("href");

    if (linkPage === currentPage) {
      // Make the current page link stand out a bit
      link.style.fontWeight = "bold";
      link.style.borderBottom = "2px solid black";
    }
  }


  var form = document.querySelector("form");

  if (form) {
    form.addEventListener("submit", function(event) {
      // Stop the page from refreshing when the form is submitted
      event.preventDefault();

      // Get the values the user typed in
      var fullName = document.getElementById("fullName").value.trim();
      var email = document.getElementById("email").value.trim();
      var message = document.getElementById("message").value.trim();
      var enquiryType = document.getElementById("enquiryType").value;

      // Simple checks to make sure required fields are filled
      if (fullName === "" || email === "" || message === "" || enquiryType === "") {
        alert("Please fill in all the required fields.");
        return; // stop here if something is missing
      }

      if (email.indexOf("@") === -1 || email.indexOf(".") === -1) {
        alert("Please enter a valid email address.");
        return;
      }

      alert("Thank you " + fullName + "! Your enquiry has been sent.\nWe will reply within 1-2 working days.");

      // Clear the form after submitting
      form.reset();
    });
  }

});